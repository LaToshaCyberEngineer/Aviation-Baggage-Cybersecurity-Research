# One time installation of the notebook defense README files

These files are meant to sit beside the notebooks under `00_Notebooks/`.

1. Download `Notebook_Defense_READMEs_01_to_12.zip` from ChatGPT.
2. In GitHub Codespaces, upload the ZIP into the **root** of `Aviation-Baggage-Cybersecurity-Research` using VS Code Explorer (right click and choose Upload).
3. In the Codespaces terminal, paste this **single block**:

```bash
unzip -o Notebook_Defense_READMEs_01_to_12.zip '00_Notebooks/*' -d .
git add 00_Notebooks/*_README.md 00_Notebooks/DEFENSE_README_INDEX.md
git commit -m "Add doctoral defense study guides for notebooks 01 to 12"
git push origin main
```

The ZIP contains **no notebook files, datasets, or experimental output files**. It only adds Markdown guides and an index. It does not create a guide for Notebook 05 or 13.

**Important:** The guide content was prepared from previously supplied notebook copies, not directly from the latest GitHub repository. Check saved numeric outputs against the current notebooks before the defense. Do not repeat this import if you have edited the guides without first preserving your changes.
